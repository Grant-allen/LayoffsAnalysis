# -*- coding: utf-8 -*-
"""
Created on Tue Apr 25 15:16:49 2023

@author: grant
"""

#calling all six functions related to the six statements from utilities.py
from utilities import main
main()